# -*- coding: utf-8 -*-
from __future__ import print_function
import os
import subprocess
from flask import Flask, request, jsonify

app = Flask(__name__)

# Optional simple auth via header
ACTION_TOKEN = os.environ.get("ACTION_TOKEN", "")

def _run_bash(cmd, timeout=120):
    """
    Run a command through bash -lc so we can source ROS/Intera env first.
    Provide comma-separated scripts in SAWYER_ENV_SCRIPTS.
    """
    env_scripts = os.environ.get("SAWYER_ENV_SCRIPTS", "")
    sources = ""
    if env_scripts:
        for p in env_scripts.split(","):
            p = p.strip()
            if p:
                sources += "source {} >/dev/null 2>&1 && ".format(p)
    full = "{}{}".format(sources, cmd)
    proc = subprocess.Popen(
        ["/bin/bash", "-lc", full],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT
    )
    try:
        out, _ = proc.communicate(timeout=timeout)
    except TypeError:
        # Python 2: no timeout kw; emulate with wait + poll
        import time
        waited = 0
        step = 0.5
        while proc.poll() is None and waited < timeout:
            time.sleep(step)
            waited += step
        if proc.poll() is None:
            try:
                proc.kill()
            except Exception:
                pass
            out = b"TIMEOUT"
        else:
            out = proc.stdout.read()
    rc = proc.returncode
    text = out.decode("utf-8", "ignore") if isinstance(out, bytes) else out
    if rc != 0:
        raise RuntimeError(text.strip())
    return text.strip()

@app.route("/enable", methods=["POST"])
def enable():
    if ACTION_TOKEN and request.headers.get("X-Action-Token", "") != ACTION_TOKEN:
        return jsonify(ok=False, error="unauthorized"), 401
    try:
        out = _run_bash("rosrun intera_interface enable_robot.py -e", timeout=120)
        return jsonify(ok=True, msg=out)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500

@app.route("/home", methods=["POST"])
def home_robot():
    if ACTION_TOKEN and request.headers.get("X-Action-Token", "") != ACTION_TOKEN:
        return jsonify(ok=False, error="unauthorized"), 401
    try:
        out = _run_bash("python home.py", timeout=120)
        return jsonify(ok=True, msg=out)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500

@app.route("/start", methods=["POST"])
def start_position():
    if ACTION_TOKEN and request.headers.get("X-Action-Token", "") != ACTION_TOKEN:
        return jsonify(ok=False, error="unauthorized"), 401
    try:
        # NOTE: fixed a tiny typo 'intera_amples' -> 'intera_examples'
        _run_bash("rosrun intera_examples head_display_image.py -f sawyerface/sawyerface.jpg", timeout=30)
        _run_bash("rosrun intera_examples go_to_joint_angles.py -q 0.68 0.8807 0.5631 -2.17 1.3 0.07 0.177 -s 0.4", timeout=120)
        _run_bash("rosrun intera_examples go_to_joint_angles.py -q 0.68 0.8807 0.5631 -2.17 1.3 0.8 0.177 -s 0.8", timeout=30)
        out = _run_bash("rosrun intera_examples go_to_joint_angles.py -q 0.68 0.8807 0.5631 -2.17 1.3 0.07 0.177 -s 0.8", timeout=120)
        return jsonify(ok=True, msg=out)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500

@app.route("/widowX", methods=["POST"])
def point_at_widowX():
    if ACTION_TOKEN and request.headers.get("X-Action-Token", "") != ACTION_TOKEN:
        return jsonify(ok=False, error="unauthorized"), 401
    try:
        # NOTE: fixed a tiny typo 'intera_amples' -> 'intera_examples'
        out = _run_bash("rosrun intera_examples go_to_joint_angles.py -q -0.07 -0.1217 1.0854 -0.0749 1.408 -0.55 0.1697 -s 0.4", timeout=120)
        return jsonify(ok=True, msg=out)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500

@app.route("/scanner", methods=["POST"])
def point_at_scanner():
    if ACTION_TOKEN and request.headers.get("X-Action-Token", "") != ACTION_TOKEN:
        return jsonify(ok=False, error="unauthorized"), 401
    try:
        _run_bash("rosrun intera_examples go_to_joint_angles.py -q 1.368 0.9861 -0.515 -2.082 0.0047 0.979 0.7452 -s 0.4", timeout=120)
        out = _run_bash("rosrun intera_examples go_to_joint_angles.py -q 1.4518 0.7265 -0.6083 -1.566 -0.2046 0.7256 0.7456 -s 0.4", timeout=120)
        _run_bash("rosrun intera_examples go_to_joint_angles.py -q 1.368 0.9861 -0.515 -2.082 0.0047 0.979 0.7452 -s 0.4", timeout=120)
        return jsonify(ok=True, msg=out)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500


# -----------------------------
# NEW: talking state publishers
# -----------------------------
def _auth_or_401():
    if ACTION_TOKEN and request.headers.get("X-Action-Token", "") != ACTION_TOKEN:
        return False, (jsonify(ok=False, error="unauthorized"), 401)
    return True, None

@app.route("/_start_talking", methods=["POST"])
def start_talking():
    ok, err = _auth_or_401()
    if not ok:
        return err
    try:
        # Publish once: /is_talking = True
        out = _run_bash('rostopic pub -1 /is_talking std_msgs/Bool "data: true"', timeout=10)
        return jsonify(ok=True, msg=out or "published: true")
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500

@app.route("/_stop_talking", methods=["POST"])
def stop_talking():
    ok, err = _auth_or_401()
    if not ok:
        return err
    try:
        # Publish once: /is_talking = False
        out = _run_bash('rostopic pub -1 /is_talking std_msgs/Bool "data: false"', timeout=10)
        return jsonify(ok=True, msg=out or "published: false")
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500

if __name__ == "__main__":
    # Bind to all interfaces inside the container; you’ll port-map or use host net
    app.run(host="0.0.0.0", port=8001, debug=False, threaded=True)

