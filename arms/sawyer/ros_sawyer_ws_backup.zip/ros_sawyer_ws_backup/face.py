#!/usr/bin/env python
# ROS Melodic / Python 2.7
import os
import rospy
from std_msgs.msg import Bool
from intera_interface import HeadDisplay

class FaceAnimator(object):
    def __init__(self):
        # Params
        self.images_dir = rospy.get_param('~images_dir', 'sawyerface')
        self.rate_hz    = rospy.get_param('~rate', 5.0)  # FPS for looping 0-4

        # Files (0.jpg..4.jpg loop; 5.jpg when talking)
        self.loop_files   = [os.path.join(self.images_dir, "%d.jpg" % i) for i in range(5)]
        self.talking_file = os.path.join(self.images_dir, "5.jpg")

        # State
        self.is_talking = False
        self.last_displayed = None
        self.idx = 0

        # Display + sub
        self.display = HeadDisplay()
        rospy.Subscriber('/is_talking', Bool, self._cb_talking, queue_size=1)

        # Basic existence checks (log warnings if any missing)
        all_files = self.loop_files + [self.talking_file]
        missing = [f for f in all_files if not os.path.isfile(f)]
        if missing:
            rospy.logwarn("Missing image files: %s", ", ".join(missing))
        else:
            rospy.loginfo("All face images found in: %s", os.path.abspath(self.images_dir))

    def _cb_talking(self, msg):
        self.is_talking = bool(msg.data)

    def _show(self, path):
        # Avoid spamming the same image
        if path != self.last_displayed:
            try:
                self.display.display_image(path)
                self.last_displayed = path
            except Exception as e:
                rospy.logerr("Failed to display %s: %s", path, e)

    def spin(self):
        rate = rospy.Rate(self.rate_hz)
        while not rospy.is_shutdown():
            if self.is_talking:
                self._show(self.talking_file)
            else:
                # loop 0.jpg..4.jpg
                self._show(self.loop_files[self.idx])
                self.idx = (self.idx + 1) % len(self.loop_files)
            rate.sleep()

if __name__ == "__main__":
    rospy.init_node("sawyer_face_animator")
    FaceAnimator().spin()

