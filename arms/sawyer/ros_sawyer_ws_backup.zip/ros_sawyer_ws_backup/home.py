#!/usr/bin/env python
import rospy
import intera_interface
from intera_interface import CHECK_VERSION, RobotEnable

rospy.init_node("go_neutral")
RobotEnable(CHECK_VERSION).enable()

limb = intera_interface.Limb('right')
limb.move_to_neutral(timeout=15.0)   # moves all joints to Rethink defined neutral pose

