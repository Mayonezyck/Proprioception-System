#!/usr/bin/env python
# Sawyer Intera SDK (ROS Melodic / Python 2.7)
import rospy, math
from copy import deepcopy
from geometry_msgs.msg import Pose, PoseStamped
from intera_interface import RobotEnable, CHECK_VERSION, Limb
from intera_motion_interface import MotionTrajectory, MotionWaypoint, MotionWaypointOptions
from intera_core_msgs.msg import InteractionControlCommand
from intera_core_msgs.srv import SolvePositionIK, SolvePositionIKRequest

def pose_from_endpoint(ep):
    p = Pose()
    p.position.x = ep['position'].x
    p.position.y = ep['position'].y
    p.position.z = ep['position'].z
    p.orientation.x = ep['orientation'].x
    p.orientation.y = ep['orientation'].y
    p.orientation.z = ep['orientation'].z
    p.orientation.w = ep['orientation'].w
    return p

def ps_from_pose(pose, frame="base"):
    ps = PoseStamped()
    ps.header.stamp = rospy.Time.now()
    ps.header.frame_id = frame
    ps.pose = pose
    return ps

def offset_pose(p, dx=0.0, dy=0.0, dz=0.0):
    q = deepcopy(p)
    q.position.x += dx
    q.position.y += dy
    q.position.z += dz
    return q

def enable_interaction_control():
    pub = rospy.Publisher('/robot/limb/right/interaction_control_command',
                          InteractionControlCommand, queue_size=10)
    rospy.sleep(0.5)
    msg = InteractionControlCommand()
    msg.header.stamp = rospy.Time.now()
    msg.endpoint_name = "right_hand"
    idf = Pose(); idf.orientation.w = 1.0
    msg.interaction_frame = idf
    try:
        msg.in_endpoint_frame = True
    except AttributeError:
        pass
    msg.interaction_control_mode = [InteractionControlCommand.IMPEDANCE_MODE]*6
    msg.K_impedance   = [180, 180, 180, 25, 25, 25]  # soft translations, firmer rotations
    msg.max_impedance = [0, 0, 0, 1, 1, 1]
    msg.force_command = [0]*6
    msg.K_nullspace   = [15]*7
    msg.interaction_control_active = True
    for _ in range(15):
        pub.publish(msg); rospy.sleep(0.05)

def ik_ok(ps):
    """Check IK with the official Sawyer IK service."""
    srv_name = '/ExternalTools/right/PositionKinematicsNode/IKService'
    rospy.wait_for_service(srv_name)
    ik = rospy.ServiceProxy(srv_name, SolvePositionIK)
    req = SolvePositionIKRequest()
    req.pose_stamp.append(ps)
    try:
        resp = ik(req)
        return (resp.isValid[0] == True)
    except rospy.ServiceException:
        return False

def main():
    rospy.init_node('sawyer_ic_triangle_demo_robust')
    RobotEnable(CHECK_VERSION).enable()
    enable_interaction_control()

    limb = Limb('right')
    names = limb.joint_names()

    # Go to neutral to avoid singular/edge postures
    limb.move_to_neutral()

    # Build trajectory
    traj = MotionTrajectory(limb=limb)
    wopt = MotionWaypointOptions(max_joint_speed_ratio=0.2)

    # WP0: seed with current joints (ordered LIST)
    wp0 = MotionWaypoint(options=wopt, limb=limb)
    wp0.set_joint_angles([limb.joint_angle(j) for j in names])
    traj.append_waypoint(wp0)

    # Start pose (neutral hand pose)
    start_pose = pose_from_endpoint(limb.endpoint_pose())

    # Triangle params: smaller + more Z lift for clearance
    side = 0.03                         # 3 cm edges
    dz   = 0.025                        # 2.5 cm lift
    dx   = side
    dy   = side * math.sqrt(3.0) / 2.0

    A = offset_pose(start_pose, 0.0,     0.0, dz)
    B = offset_pose(start_pose, dx,      0.0, dz)
    C = offset_pose(start_pose, dx/2.0,  dy,  dz)

    def add_cart_wp_if_valid(pose):
        ps = ps_from_pose(pose, frame="base")
        if not ik_ok(ps):
            rospy.logwarn("IK invalid for a vertex; skipping.")
            return False
        wp = MotionWaypoint(options=wopt, limb=limb)
        ok = wp.set_cartesian_pose(ps)   # old signature; no kwargs
        if not ok:
            rospy.logwarn("MotionWaypoint IK set failed; skipping.")
            return False
        traj.append_waypoint(wp)
        return True

    # Try to append vertices; require at least two Cartesian waypoints
    count = 0
    for v in (A, B, C, A):
        if add_cart_wp_if_valid(v):
            count += 1

    if count < 2:
        raise RuntimeError("No valid Cartesian waypoints found (even after neutral + small triangle).")

    result = traj.send_trajectory(timeout=45.0)
    print("Trajectory result:", result)

if __name__ == "__main__":
    try:
        main()
    except rospy.ROSInterruptException:
        pass

