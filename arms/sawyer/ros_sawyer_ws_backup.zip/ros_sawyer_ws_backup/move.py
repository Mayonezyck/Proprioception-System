#!/usr/bin/env python
import rospy, PyKDL
from tf_conversions import posemath
from geometry_msgs.msg import PoseStamped
from intera_interface import Limb
from intera_motion_interface import MotionTrajectory, MotionWaypoint, MotionWaypointOptions
from intera_motion_msgs.msg import TrajectoryOptions

def jog_x(dx=0.10, tip='right_hand'):
    rospy.init_node('cartesian_jog_x')
    limb = Limb()

    # Cartesian trajectory
    topts = TrajectoryOptions()
    topts.interpolation_type = TrajectoryOptions.CARTESIAN
    traj = MotionTrajectory(trajectory_options=topts, limb=limb)

    wopt = MotionWaypointOptions(max_linear_speed=0.25,
                                 max_linear_accel=0.25,
                                 max_rotational_speed=1.0,
                                 max_rotational_accel=1.0,
                                 max_joint_speed_ratio=0.3)
    wp = MotionWaypoint(options=wopt.to_msg(), limb=limb)

    # Current tip pose
    ep = limb.tip_state(tip)
    if ep is None:
        raise RuntimeError('No tip state')

    pose = ep.pose  # geometry_msgs/Pose

    # Build a relative transform in BASE frame: +dx in X, 0 rot
    rot = PyKDL.Rotation.RPY(0, 0, 0)
    trans = PyKDL.Vector(dx, 0, 0)
    f_rel = PyKDL.Frame(rot, trans)

    # Apply: base-relative * current_pose
    pose_next = posemath.toMsg(f_rel * posemath.fromMsg(pose))

    ps = PoseStamped()
    ps.pose = pose_next
    # Same signature as the example:
    wp.set_cartesian_pose(ps, tip, [])   # [] = no joint bias

    traj.append_waypoint(wp.to_msg())
    res = traj.send_trajectory(timeout=15.0)
    print('OK' if res and res.result else 'FAILED', res.errorId if res else None)

if __name__ == "__main__":
    jog_x(0.10)

